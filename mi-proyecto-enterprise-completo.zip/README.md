# 🚀 mi-proyecto-enterprise

Enterprise bootstrap con:

- GSD (metodología base)
- Anti-Chaotic (selectivo)
- Docker
- GitHub Actions CI
- Arquitectura modular tipo monorepo

## ▶️ Ejecutar local

npm install
npm run dev

## 🐳 Ejecutar con Docker

docker build -t mi-proyecto .
docker run -p 3000:3000 mi-proyecto

o

docker-compose up --build

## 🔁 CI

GitHub Actions corre automáticamente en push a main.

## 📦 Subir a GitHub

git init
git add .
git commit -m "initial enterprise bootstrap"
git branch -M main
git remote add origin TU_REPO_URL
git push -u origin main
