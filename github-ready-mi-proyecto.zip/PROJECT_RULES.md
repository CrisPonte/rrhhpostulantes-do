# PROJECT RULES

Base rules from GSD.
