# lead-architect skill
